# SCI Figure Index

Generated: 20260414_191314
Total figures: 51 (PNG + PDF each)

| # | File | Description |
|---|------|-------------|
| 1 | `demo_00_surface_subsidence/surface/fig01_odi_heatmap.png/pdf` | ODI heatmap (blueRed, 5-step) |
| 2 | `demo_00_surface_subsidence/surface/fig02_geology_cloud.png/pdf` | Geology cloud (Ti, Hi, Di, Mi) |
| 3 | `demo_00_surface_subsidence/surface/fig03_spatial_map.png/pdf` | Spatial map |
| 4 | `demo_00_surface_subsidence/surface/fig04_odi_histogram.png/pdf` | ODI histogram |
| 5 | `demo_00_surface_subsidence/surface/fig05_odi_level_pie.png/pdf` | ODI level pie (I-V) |
| 6 | `demo_00_surface_subsidence/surface/fig06_param_scatter.png/pdf` | Parameter scatter matrix |
| 7 | `demo_00_surface_subsidence/surface/fig07a_error_trend_line1.png/pdf` | Error trend: 测线1 |
| 8 | `demo_00_surface_subsidence/surface/fig07b_error_trend_line2.png/pdf` | Error trend: 测线2 |
| 9 | `demo_00_surface_subsidence/surface/fig07c_error_trend_line3.png/pdf` | Error trend: 测线3 |
| 10 | `demo_00_surface_subsidence/surface/fig08_weight_radar.png/pdf` | Weight radar |
| 11 | `demo_01_aquifer_pre_eval/aquifer/fig01_odi_heatmap.png/pdf` | ODI heatmap (blueRed, 5-step) |
| 12 | `demo_01_aquifer_pre_eval/aquifer/fig02_geology_cloud.png/pdf` | Geology cloud (Ti, Hi, Di, Mi) |
| 13 | `demo_01_aquifer_pre_eval/aquifer/fig03_spatial_map.png/pdf` | Spatial map |
| 14 | `demo_01_aquifer_pre_eval/aquifer/fig04_odi_histogram.png/pdf` | ODI histogram |
| 15 | `demo_01_aquifer_pre_eval/aquifer/fig05_odi_level_pie.png/pdf` | ODI level pie (I-V) |
| 16 | `demo_01_aquifer_pre_eval/aquifer/fig06_param_scatter.png/pdf` | Parameter scatter matrix |
| 17 | `demo_01_aquifer_pre_eval/aquifer/fig07_weight_radar.png/pdf` | Weight radar |
| 18 | `demo_02_aquifer_eval/aquifer/fig01_odi_heatmap.png/pdf` | ODI heatmap (blueRed, 5-step) |
| 19 | `demo_02_aquifer_eval/aquifer/fig02_geology_cloud.png/pdf` | Geology cloud (Ti, Hi, Di, Mi) |
| 20 | `demo_02_aquifer_eval/aquifer/fig03_spatial_map.png/pdf` | Spatial map |
| 21 | `demo_02_aquifer_eval/aquifer/fig04_odi_histogram.png/pdf` | ODI histogram |
| 22 | `demo_02_aquifer_eval/aquifer/fig05_odi_level_pie.png/pdf` | ODI level pie (I-V) |
| 23 | `demo_02_aquifer_eval/aquifer/fig06_param_scatter.png/pdf` | Parameter scatter matrix |
| 24 | `demo_02_aquifer_eval/aquifer/fig07_weight_radar.png/pdf` | Weight radar |
| 25 | `demo_03_mining_planning/aquifer/fig01_odi_heatmap.png/pdf` | ODI heatmap (blueRed, 5-step) |
| 26 | `demo_03_mining_planning/aquifer/fig02_geology_cloud.png/pdf` | Geology cloud (Ti, Hi, Di, Mi) |
| 27 | `demo_03_mining_planning/aquifer/fig03_spatial_map.png/pdf` | Spatial map |
| 28 | `demo_03_mining_planning/aquifer/fig04_odi_histogram.png/pdf` | ODI histogram |
| 29 | `demo_03_mining_planning/aquifer/fig05_odi_level_pie.png/pdf` | ODI level pie (I-V) |
| 30 | `demo_03_mining_planning/aquifer/fig06_param_scatter.png/pdf` | Parameter scatter matrix |
| 31 | `demo_03_mining_planning/aquifer/fig07_weight_radar.png/pdf` | Weight radar |
| 32 | `demo_04_cocontrol/aquifer/fig01_odi_heatmap.png/pdf` | ODI heatmap (blueRed, 5-step) |
| 33 | `demo_04_cocontrol/aquifer/fig02_geology_cloud.png/pdf` | Geology cloud (Ti, Hi, Di, Mi) |
| 34 | `demo_04_cocontrol/aquifer/fig03_spatial_map.png/pdf` | Spatial map |
| 35 | `demo_04_cocontrol/aquifer/fig04_odi_histogram.png/pdf` | ODI histogram |
| 36 | `demo_04_cocontrol/aquifer/fig05_odi_level_pie.png/pdf` | ODI level pie (I-V) |
| 37 | `demo_04_cocontrol/aquifer/fig06_param_scatter.png/pdf` | Parameter scatter matrix |
| 38 | `demo_05_succession/aquifer/fig01_odi_heatmap.png/pdf` | ODI heatmap (blueRed, 5-step) |
| 39 | `demo_05_succession/aquifer/fig02_geology_cloud.png/pdf` | Geology cloud (Ti, Hi, Di, Mi) |
| 40 | `demo_05_succession/aquifer/fig03_spatial_map.png/pdf` | Spatial map |
| 41 | `demo_05_succession/aquifer/fig04_odi_histogram.png/pdf` | ODI histogram |
| 42 | `demo_05_succession/aquifer/fig05_odi_level_pie.png/pdf` | ODI level pie (I-V) |
| 43 | `demo_05_succession/aquifer/fig06_param_scatter.png/pdf` | Parameter scatter matrix |
| 44 | `demo_05_succession/aquifer/fig07_weight_radar.png/pdf` | Weight radar |
| 45 | `demo_06_full_overburden/full/fig01_odi_heatmap.png/pdf` | ODI heatmap (blueRed, 5-step) |
| 46 | `demo_06_full_overburden/full/fig02_geology_cloud.png/pdf` | Geology cloud (Ti, Hi, Di, Mi) |
| 47 | `demo_06_full_overburden/full/fig03_spatial_map.png/pdf` | Spatial map |
| 48 | `demo_06_full_overburden/full/fig04_odi_histogram.png/pdf` | ODI histogram |
| 49 | `demo_06_full_overburden/full/fig05_odi_level_pie.png/pdf` | ODI level pie (I-V) |
| 50 | `demo_06_full_overburden/full/fig06_param_scatter.png/pdf` | Parameter scatter matrix |
| 51 | `demo_06_full_overburden/full/fig07_weight_radar.png/pdf` | Weight radar |
